package app.stillscreen.focus

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * A block screen drawn as an accessibility overlay. It is the backup for
 * phones that refuse to open the normal block screen from the background.
 * An accessibility service may add this kind of window without any extra
 * permission or pop-up setting, so it works the same on every brand.
 */
class BlockOverlay(private val service: AccessibilityService) {

    private var view: View? = null
    private var currentWindDown = false

    /** The app this overlay is covering, or null when nothing is shown. */
    var blockedPackage: String? = null
        private set

    val isShowing: Boolean get() = view != null

    /** Returns false if the phone would not let the window be added. */
    fun show(pkg: String, windDown: Boolean): Boolean {
        val existing = view
        if (existing != null) {
            // If the system removed the window, forget it and draw a new one.
            if (existing.isAttachedToWindow) return true
            view = null
            blockedPackage = null
        }
        return try {
            val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            currentWindDown = windDown
            val content = build(pkg, windDown)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE
            ).apply { gravity = Gravity.CENTER }
            wm.addView(content, params)
            content.requestFocus()
            view = content
            blockedPackage = pkg
            true
        } catch (e: Exception) {
            view = null
            blockedPackage = null
            false
        }
    }

    fun hide() {
        val current = view ?: return
        view = null
        blockedPackage = null
        try {
            val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.removeView(current)
        } catch (e: Exception) {
            // Already gone.
        }
    }

    private fun leave() {
        if (!currentWindDown) BlockStore.recordFocusChosen(service)
        hide()
        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
    }

    /** Same words and colours as BlockActivity, so the two look alike. */
    private fun build(pkg: String, windDown: Boolean): View {
        val density = service.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val appName = BlockInfo.appName(service, pkg)

        val message = TextView(service).apply {
            text = if (windDown) {
                "Time to switch off.\n$appName is paused until your work hours start."
            } else {
                "Take a breath.\n$appName is blocked during your focus session."
            }
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        val reason = BlockStore.reason(service)
        val reasonView = TextView(service).apply {
            text = "\u201C$reason\u201D"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(0xFF62B5B0.toInt())
            setTypeface(typeface, Typeface.ITALIC)
            setPadding(dp(16), 0, dp(16), dp(24))
        }
        val button = Button(service).apply {
            text = if (windDown) "Okay" else "Back to focus"
            isAllCaps = false
            textSize = 16f
            stateListAnimator = null
            setTextColor(0xFF14323A.toInt())
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(0xFF62B5B0.toInt())
            }
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener { leave() }
        }

        val scrollRoot = object : ScrollView(service) {
            // Back leaves, the same as the button, instead of revealing the app.
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                    if (event.action == KeyEvent.ACTION_UP) leave()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        val content = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            addView(message)
            BlockInfo.breathingViews(service).forEach { addView(it) }
            BlockInfo.topViews(service, windDown).forEach { addView(it) }
            if (reason.isNotEmpty()) addView(reasonView)
            BlockInfo.footerViews(service, windDown).forEach { addView(it) }
            addView(
                button,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }
        return scrollRoot.apply {
            isFillViewport = true
            isFocusable = true
            isFocusableInTouchMode = true
            setBackgroundColor(0xFF14323A.toInt())
            addView(content)
        }
    }
}
