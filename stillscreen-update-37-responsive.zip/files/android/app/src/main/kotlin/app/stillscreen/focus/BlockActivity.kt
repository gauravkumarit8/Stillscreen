package app.stillscreen.focus

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.window.OnBackInvokedDispatcher
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Block screen for focus sessions and wind-down. Built in code, no layout files. */
class BlockActivity : Activity() {

    private var windDown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        windDown = intent.getStringExtra(EXTRA_REASON) == REASON_WIND_DOWN
        val appName = BlockInfo.appName(this, intent.getStringExtra(EXTRA_PACKAGE))
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val message = TextView(this).apply {
            text = if (windDown) {
                "Time to switch off.\n$appName is paused until your work hours start."
            } else {
                "Take a breath.\n$appName is blocked during your focus session."
            }
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        val reason = BlockStore.reason(this)
        val reasonView = TextView(this).apply {
            text = "\u201C$reason\u201D"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(0xFF62B5B0.toInt())
            setTypeface(typeface, Typeface.ITALIC)
            setPadding(dp(16), 0, dp(16), dp(24))
        }
        val button = Button(this).apply {
            text = if (windDown) "Okay" else "Back to focus"
            isAllCaps = false
            textSize = 16f
            stateListAnimator = null
            setTextColor(0xFF14323A.toInt())
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(0xFF62B5B0.toInt())
            }
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener { goHome() }
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF14323A.toInt())
            setPadding(dp(24), dp(24), dp(24), dp(24))
            addView(message)
            BlockInfo.breathingViews(this@BlockActivity).forEach { addView(it) }
            BlockInfo.topViews(this@BlockActivity, windDown).forEach { addView(it) }
            if (reason.isNotEmpty()) addView(reasonView)
            BlockInfo.footerViews(this@BlockActivity, windDown).forEach { addView(it) }
            addView(
                button,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }
        // Scrollable, so small screens, big fonts and landscape still reach
        // the button. fillViewport keeps the content centred when it fits.
        setContentView(
            ScrollView(this).apply {
                isFillViewport = true
                setBackgroundColor(0xFF14323A.toInt())
                addView(root)
            }
        )

        // Android 13+ with predictive back never calls onBackPressed, so Back
        // would simply close this screen and reveal the blocked app. Register
        // for the new back event as well.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT
            ) { goHome() }
        }
    }

    override fun onResume() {
        super.onResume()
        onScreen = true
    }

    override fun onPause() {
        onScreen = false
        super.onPause()
    }

    @Deprecated("Back always returns home while blocking is active")
    override fun onBackPressed() = goHome()

    private fun goHome() {
        if (!windDown) BlockStore.recordFocusChosen(this)
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    companion object {
        /**
         * True only while this screen is in front and active. Created is not
         * enough: a phone can start it behind the app that is open.
         */
        @Volatile
        var onScreen: Boolean = false

        const val EXTRA_PACKAGE = "blocked_package"
        const val EXTRA_REASON = "block_reason"
        const val REASON_FOCUS = "focus"
        const val REASON_WIND_DOWN = "wind_down"
    }
}
