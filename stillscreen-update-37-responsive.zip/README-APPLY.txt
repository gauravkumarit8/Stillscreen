Stillscreen update 37: responsive layout fixes
===============================================
Fixes the cut-off Continue button on the first screen and the same kind of
problem on other screens, for small phones, large fonts, landscape and tablets.

Apply (PowerShell, in the project folder, on a clean working tree):

  git apply --check update-37-responsive-layout.patch
  git apply update-37-responsive-layout.patch
  git status --short
  git add -A
  git commit -m "Responsive layout fixes"
  git push

Never run the patch twice. It does not touch pubspec.yaml, so your local
version edits are safe. Do NOT extract the files/ folder over the repo if you
used the patch; it is only a backup copy of the changed files.

Then:
 1. Wait for the GitHub Actions build to pass (it runs flutter analyze).
 2. Install the debug APK and follow docs/RESPONSIVE_TEST_CHECKLIST.md.
 3. Raise the version code and release as its own small staged rollout.
